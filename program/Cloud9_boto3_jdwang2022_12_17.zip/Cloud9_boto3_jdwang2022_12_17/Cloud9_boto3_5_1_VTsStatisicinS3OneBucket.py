#
# # Jing-Doo Wang, jdwang@asia.edu.tw, 2022/12/14
#
from os import listdir
from os.path import isfile, isdir, join
import os
import pandas as pd
import boto3
import botocore
from pathlib import Path 

#BUCKET_NAME = 'tdcs-m06a-jdwang-2022-12-1-7'
BUCKET_NAME = 'tdcs-m06a-upload-from-cloud9-jdwang-2022'
OutputDir = './'+BUCKET_NAME+'_VTs_24H'+'/'
Pathname = OutputDir
Target_Field = 'GantryID_O'
Target_Value = '03F1860S'

# https://www.geeksforgeeks.org/python-check-if-a-file-or-directory-exists-2/
#import os

if os.path.exists(OutputDir):
    print(OutputDir+" Existed!")
else:
    #Create a directory in Python
    #https://www.geeksforgeeks.org/create-a-directory-in-python/
    os.mkdir(OutputDir)
    print("Directory '% s' created" % OutputDir)

#OutputFileLocation = OutputDir+"/"+FILE_NAME;

FieldNames= ['VehicleType', 'DetectionTime_O', 'GantryID_O', 'DetectionTime_D','GantryID_D','TripLength','TripEnd','TripInformation'] 
FieldNames_Selected =  ['VehicleType', 'DetectionTime_O', 'GantryID_O', 'DetectionTime_D','GantryID_D','TripLength','TripEnd'] 

df = pd.DataFrame(columns=FieldNames_Selected)

s3 = boto3.resource('s3')

my_bucket = s3.Bucket(BUCKET_NAME)

for file in my_bucket.objects.all():
    print(file.key)
    FILE_NAME = file.key
    OutputFileLocation = OutputDir+FILE_NAME
    #
    # From: https://github.com/rchidana/Python_Boto3/blob/master/S3download.py
    # rchidana
    try:
        #s3.Bucket(BUCKET_NAME).download_file(FILE_NAME,FILE_NAME)
        s3.Bucket(BUCKET_NAME).download_file(FILE_NAME,OutputFileLocation)
        print("Downloaded File : ",FILE_NAME," successfully from Bucket : ",BUCKET_NAME)
    except botocore.exceptions.ClientError as e:
        if e.response['Error']['Code'] == "404":
            print("The File ",FILE_NAME," does not exist in Bucket : ",BUCKET_NAME)
        else:
            raise
    print(OutputFileLocation)
    
    data = pd.read_csv(OutputFileLocation, encoding='utf-8', header=0, names=FieldNames, delimiter=",", low_memory=False) 
    
    df = pd.DataFrame(data[FieldNames_Selected])
    
    df['DetectionTime_O'] = df['DetectionTime_O'].astype('datetime64[ns]')
    df['Year'] = df.DetectionTime_O.dt.year
    df['Month'] = df.DetectionTime_O.dt.month
    df['Day'] = df.DetectionTime_O.dt.day
    df['Weekday'] = df.DetectionTime_O.dt.day_name()
    df['Hour_0'] = df.DetectionTime_O.dt.hour
    
    df_One_GantryID_O = df[(df[Target_Field]==Target_Value)]
    
    OneDayVT24HRecords = df_One_GantryID_O.groupby(['Year','Month','Day','Weekday','Hour_0','VehicleType']).size().reset_index(name='counts')
    
    #Pathname = "./VTs_24H/"
    #FileName = "VTs_24H_"+Target_Field+"_"+Target_Value+"_"+str(Target_Year) +"_"+str(Target_Month) +"_"+str(Target_Day) +".csv"
    FileName = "VTs_24H_"+Target_Field+"_"+Target_Value+".csv"
    filepath = Path(Pathname+FileName)
    filepath.parent.mkdir(parents=True, exist_ok=True) 
    
    if os.path.exists(filepath):
        OneDayVT24HRecords.to_csv(filepath,mode='a',index=False,header=False)
    else:
        OneDayVT24HRecords.to_csv(filepath,mode='w',index=False,header=True)
        
    # Python Delete File https://www.w3schools.com/python/python_file_remove.asp    
    if os.path.exists(OutputFileLocation):
        os.remove(OutputFileLocation)
        print("The file removed =>"+  OutputFileLocation)
    else:
        print("The file does not exist=>"+  OutputFileLocation)
       
    