#
# https://boto3.amazonaws.com/v1/documentation/api/latest/guide/s3-example-creating-buckets.html
# 
# Jing-Doo Wang, jdwang@asia.edu.tw
import sys
import boto3
from botocore.exceptions import ClientError
# Create an Amazon S3 Bucket
# The example below shows how to create a new bucket using create_bucket.
#NewBucketName = "TDCS_M06A_jdwang_2022_12_9"
#NewBucketName = 'tdcs_m06a_cloud9_upload_jdwang_2022_12_9'
NewBucketName = 'tdcs-m06a-jdwang-2023'
#RegionName = 'us-east-1'
s3_client = boto3.client('s3');
# Create an Amazon S3 Bucket
# The example below shows how to create a new bucket using create_bucket.
s3_client.create_bucket(Bucket=NewBucketName)
# Retrieve the list of existing buckets
#s3_client = boto3.client('s3')
response = s3_client.list_buckets()
# Output the bucket names
print('Existing buckets:')
for bucket in response['Buckets']:
    print(f'  {bucket["Name"]}')
