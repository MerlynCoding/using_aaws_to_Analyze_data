import boto3

def get_total_objects_in_bucket(bucket_name):
    # Create an S3 client
    s3 = boto3.client('s3')

    # Create a paginator
    paginator = s3.get_paginator('list_objects_v2')

    # Initialize the total count
    total_objects = 0

    for page in paginator.paginate(Bucket=bucket_name):
        # Update the total count
        total_objects += page.get('KeyCount', 0)

    print(f"Total objects in bucket '{bucket_name}': {total_objects}")

# Example usage:
bucket_name = "tdcs-m06a-jdwang-2023"
get_total_objects_in_bucket(bucket_name)
