#
#  https://boto3.amazonaws.com/v1/documentation/api/latest/guide/s3-uploading-files.html
#
# Jing-Doo Wang, jdwang@asia.edu.tw, 2022/12/14
import logging
import boto3
from botocore.exceptions import ClientError
import os
#/TDCS_Download_jdwang/M06A/202212/TDCS_M06A_20221201_000000.csv
InputDir = '/home/ec2-user/environment/tdcsjdwang/'
#FILE_NAME = 'TDCS_M06A_20221201_000000.csv'
#InputFileLocation = InputDir+FILE_NAME;
UPload_BUCKET_NAME = 'tdcs-m06a-jdwang-2023'
    
#OBJECT_NAME = FILE_NAME
# https://pynative.com/python-list-files-in-a-directory/
import os
# folder path
#dir_path = r'E:\\account\\'

# list to store files
res = []
# Iterate directory
for onefile in os.listdir(InputDir):
    # check if current path is a file
    if os.path.isfile(os.path.join(InputDir, onefile)):
        res.append(onefile)
print(res)
# Uploads the given file using a managed uploader, which will split up large
# files automatically and upload parts in parallel
#s3 = boto3.client('s3')

s3 = boto3.resource('s3')

if not(s3.Bucket(UPload_BUCKET_NAME) in s3.buckets.all()):
    s3.create_bucket(Bucket=UPload_BUCKET_NAME)
else:
    print(UPload_BUCKET_NAME+" Existed!")
    

s3 = boto3.client('s3')    
	        
for onefile in os.listdir(InputDir):
    # check if current path is a file
    if os.path.isfile(os.path.join(InputDir, onefile)):
        #InputDir = './TDCS_Download_jdwang/M06A/202212/'
        #FILE_NAME = 'TDCS_M06A_20221201_040000.csv'
        FILE_NAME = onefile
        InputFileLocation = InputDir+FILE_NAME;
        OBJECT_NAME = FILE_NAME
        #response = s3.upload_file(InputFileLocation,BUCKET_NAME,OBJECT_NAME)
        #print ("Uploaded File ",InputFileLocation,"Successfully on to Bucket : ",BUCKET_NAME)
        try:
            response = s3.upload_file(InputFileLocation, UPload_BUCKET_NAME, OBJECT_NAME)
            print ("Uploaded File ",InputFileLocation," Successfully on to Bucket : ",UPload_BUCKET_NAME)
        except Exception as error:
	        print (error)
