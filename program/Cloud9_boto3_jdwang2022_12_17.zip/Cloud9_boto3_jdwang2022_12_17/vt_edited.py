
import os
import pandas as pd
from pathlib import Path 

# Specify the local directory path
LocalDirectory = '~/home/ec2-user/environment/tdcs-m06a-jdwang-2023'
Tag_TimeInterval = '2023-09-1_2023-10-22'
OutputDir = './'+LocalDirectory+'_VTs_24H'+'/'
Pathname = OutputDir
Target_Field = 'GantryID_O'
Target_Value = '03F1860S'

# if os.path.exists(OutputDir):
#     print(OutputDir+" Existed!")
# else:
#     os.mkdir(OutputDir)
#     print("Directory '% s' created" % OutputDir)

FieldNames = ['VehicleType', 'DetectionTime_O', 'GantryID_O', 'DetectionTime_D','GantryID_D','TripLength','TripEnd','TripInformation'] 
FieldNames_Selected =  ['VehicleType', 'DetectionTime_O', 'GantryID_O', 'DetectionTime_D','GantryID_D','TripLength','TripEnd'] 

# Iterate through files in the local directory
for file_name in os.listdir(LocalDirectory):
    if file_name.endswith('.csv'):
        print(file_name)
        FILE_NAME = file_name
        OutputFileLocation = os.path.join(OutputDir, FILE_NAME)

        # Read the CSV file locally
        data = pd.read_csv(os.path.join(LocalDirectory, FILE_NAME), encoding='utf-8', header=0, names=FieldNames, delimiter=",", low_memory=False) 

        df = pd.DataFrame(data[FieldNames_Selected])

        df['DetectionTime_O'] = df['DetectionTime_O'].astype('datetime64[ns]')
        df['Year'] = df.DetectionTime_O.dt.year
        df['Month'] = df.DetectionTime_O.dt.month
        df['Day'] = df.DetectionTime_O.dt.day
        df['Weekday'] = df.DetectionTime_O.dt.day_name()
        df['Hour_0'] = df.DetectionTime_O.dt.hour

        df_One_GantryID_O = df[(df[Target_Field] == Target_Value)]

        OneDayVT24HRecords = df_One_GantryID_O.groupby(['Year','Month','Day','Weekday','Hour_0','VehicleType']).size().reset_index(name='counts')

        FileName = "VTs_24H_"+Tag_TimeInterval+"_"+Target_Field+"_"+Target_Value+".csv"
        filepath = Path(Pathname+FileName)
        filepath.parent.mkdir(parents=True, exist_ok=True) 

        if os.path.exists(filepath):
            OneDayVT24HRecords.to_csv(filepath, mode='a', index=False, header=False)
        else:
            OneDayVT24HRecords.to_csv(filepath, mode='w', index=False, header=True)

        # You may want to delete the input file after processing
        # os.remove(os.path.join(LocalDirectory, FILE_NAME))
        print("The file removed =>", OutputFileLocation)
