#
#  https://boto3.amazonaws.com/v1/documentation/api/latest/guide/s3-uploading-files.html
#
# Jing-Doo Wang, jdwang@asia.edu.tw, 2022/12/14
import logging
import boto3
from botocore.exceptions import ClientError
import os
#/TDCS_Download_jdwang/M06A/202212/TDCS_M06A_20221201_000000.csv

InputDir = '/Cloud9_boto3_jdwang2022_12_17/TDCS_Download_jdwang/M06A/20231030/'


FILE_NAME = 'TDCS_M06A_20221201_000000.csv'
InputFileLocation = InputDir+FILE_NAME;

BUCKET_NAME = 'tdcs-m06a-jdwang-2022-12-9'
OBJECT_NAME = FILE_NAME


# https://pynative.com/python-list-files-in-a-directory/
import os
# folder path
#dir_path = r'E:\\account\\'
dir_path = InputDir
# list to store files
res = []
# Iterate directory
for path in os.listdir(dir_path):
    # check if current path is a file
    if os.path.isfile(os.path.join(dir_path, path)):
        res.append(path)
print(res)


# Uploads the given file using a managed uploader, which will split up large
# files automatically and upload parts in parallel.

#try:
#	response = s3.upload_file(InputFileLocation, BUCKET_NAME, OBJECT_NAME)
#	print ("Uploaded File ",InputFileLocation," Successfully on to Bucket : ",BUCKET_NAME)
#except Exception as error:
#	print (error)