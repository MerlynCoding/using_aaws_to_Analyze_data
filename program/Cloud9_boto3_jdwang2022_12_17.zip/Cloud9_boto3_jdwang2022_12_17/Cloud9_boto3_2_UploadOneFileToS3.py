#
#  https://boto3.amazonaws.com/v1/documentation/api/latest/guide/s3-uploading-files.html
#
# Jing-Doo Wang, jdwang@asia.edu.tw, 2022/12/14
import logging
import boto3
from botocore.exceptions import ClientError
import os
#/TDCS_Download_jdwang/M06A/202212/TDCS_M06A_20221201_000000.csv

InputDir = './TDCS_Download_jdwang/M06A/202212/'
FILE_NAME = 'TDCS_M06A_20221201_010000.csv'
InputFileLocation = InputDir+FILE_NAME;

BUCKET_NAME = 'tdcs-m06a-jdwang-2022-12-16'
OBJECT_NAME = FILE_NAME
# Uploads the given file using a managed uploader, which will split up large
# files automatically and upload parts in parallel.
# Create an S3 client
s3 = boto3.client('s3')
try:
	response = s3.upload_file(InputFileLocation, BUCKET_NAME, OBJECT_NAME)
	print ("Uploaded File ",InputFileLocation," Successfully on to Bucket : ",BUCKET_NAME)
except Exception as error:
	print (error)