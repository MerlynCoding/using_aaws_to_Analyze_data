import os

BUCKET_NAME = 'tdcs-m06a-jdwang-2023'
OutputDir = './' + BUCKET_NAME + '/'

if os.path.exists(OutputDir):
    print(OutputDir + " Existed!")
else:
    os.mkdir(OutputDir)
    print("Directory '%s' created" % OutputDir)

# ... (rest of your script)

# Count the total number of files in the directory
file_count = len([f for f in os.listdir(OutputDir) if os.path.isfile(os.path.join(OutputDir, f))])

print(f'Total number of files in directory {OutputDir}: {file_count}')
