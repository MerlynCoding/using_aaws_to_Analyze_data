import boto3
import botocore
import os

BUCKET_NAME = 'tdcs-m06a-jdwang-2023'
OutputDir = './' + BUCKET_NAME + '/'

if os.path.exists(OutputDir):
    print(OutputDir + " Existed!")
else:
    os.mkdir(OutputDir)
    print("Directory '%s' created" % OutputDir)

s3 = boto3.resource('s3')
my_bucket = s3.Bucket(BUCKET_NAME)

start_time = "TDCS_M06A_20230901_080000"
end_time = "TDCS_M06A_20230901_090000"

for file in my_bucket.objects.all():
    FILE_NAME = file.key
    if start_time <= FILE_NAME <= end_time:
        OutputFileLocation = OutputDir + FILE_NAME
        try:
            s3.Bucket(BUCKET_NAME).download_file(FILE_NAME, OutputFileLocation)
            print("Downloaded File:", FILE_NAME, "successfully from Bucket:", BUCKET_NAME)
        except botocore.exceptions.ClientError as e:
            if e.response['Error']['Code'] == "404":
                print("The File", FILE_NAME, "does not exist in Bucket:", BUCKET_NAME)
            else:
                raise
