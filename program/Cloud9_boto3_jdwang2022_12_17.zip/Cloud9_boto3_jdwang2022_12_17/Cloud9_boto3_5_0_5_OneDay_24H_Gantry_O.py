
# coding: utf-8
# """
# (Traffic Data Collection System)" https://tisvcloud.freeway.gov.tw/
# 
# 資料使用手冊(V3.3) https://tisvcloud.freeway.gov.tw/documents/TDCS%E4%BD%BF%E7%94%A8%E6%89%8B%E5%86%8Av33.pdf
# 
# Test Download : https://tisvcloud.freeway.gov.tw/history/TDCS/M06A/
# ---
# Jing-Doo Wang, jdwang@asia.edu.tw
# 2022/12/14
# """
from os import listdir
from os.path import isfile, isdir, join
import pandas as pd

FieldNames= ['VehicleType', 'DetectionTime_O', 'GantryID_O', 'DetectionTime_D','GantryID_D','TripLength','TripEnd','TripInformation'] 
FieldNames_Selected =  ['VehicleType', 'DetectionTime_O', 'GantryID_O', 'DetectionTime_D','GantryID_D','TripLength','TripEnd'] 
df = pd.DataFrame(columns=FieldNames_Selected)
#SrcDir = "..//TDCS_Download_jdwang//M06A//202211//"
SrcDir = ".//TDCS_Download_jdwang//M06A//202212//"
Target_Field = 'GantryID_O'
Target_Value = '03F1860S'
Target_Year = 2022
Target_Month = 12
Target_Day = 2
# 取得所有檔案與子目錄名稱
files = listdir(SrcDir)
# 以迴圈處理
for FILE_NAME in files:
    # 產生檔案的絕對路徑
    fullpath = join( SrcDir, FILE_NAME)
    if isfile(fullpath):
        print(fullpath)
        data = pd.read_csv(fullpath, encoding='utf-8', header=0, names=FieldNames, delimiter=",", low_memory=False) 
        df_Temp = pd.DataFrame(data[FieldNames_Selected])
        df = df.append(df_Temp, ignore_index=True)
        print(df_Temp.shape)
        print(df.shape)

df['DetectionTime_O'] = df['DetectionTime_O'].astype('datetime64[ns]')

df['Year'] = df.DetectionTime_O.dt.year
df['Month'] = df.DetectionTime_O.dt.month
df['Day'] = df.DetectionTime_O.dt.day
df['Weekday'] = df.DetectionTime_O.dt.day_name()
df['Hour_0'] = df.DetectionTime_O.dt.hour

# # https://www.google.com/maps/d/u/0/edit?hl=en&mid=17cUope9BBe1Tmvk-4aj6_njagh4dloHD&ll=23.757640368240114%2C121.01767499999997&z=8
# # 03F1860S (上龍井交流道-南下) (龍井交流道=>和美)
# https://kanoki.org/2020/01/21/pandas-dataframe-filter-with-multiple-conditions/ 
#
#Target_Field = 'GantryID_O'
#Target_Value = '03F1860S'
#Target_Year = 2022
#Target_Month = 11
#Target_Day = 11
#df_One_GantryID_O = df[df['GantryID_O'] == '03F1860S']
df_One_GantryID_O = df[(df[Target_Field]==Target_Value)&(df['Year']==Target_Year)&(df['Month']==Target_Month)&(df['Day']==Target_Day)]

# numpy.core._exceptions.MemoryError: Unable to allocate
# Clear Memory in Python https://www.delftstack.com/howto/python/python-clear-memory/
#
#Clear Memory in Python Using the gc.collect() Method
#Clear Memory in Python Using the del Statement
#import gc
#del df
#gc.collect()

OneDayVT24HRecords = df_One_GantryID_O.groupby(['Year','Month','Day','Weekday','Hour_0','VehicleType']).size().reset_index(name='counts')

#OneDayVT24HRecords
# https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.to_csv.html
# pandas.DataFrame.to_csv
from pathlib import Path 
#Pathname = "../VTs_24H/"
Pathname = "./VTs_24H/"
FileName = "VTs_24H_"+Target_Field+"_"+Target_Value+"_"+str(Target_Year) +"_"+str(Target_Month) +"_"+str(Target_Day) +".csv"
filepath = Path(Pathname+FileName)  
filepath.parent.mkdir(parents=True, exist_ok=True)  

OneDayVT24HRecords.to_csv(filepath) 