#
# From: https://stackoverflow.com/questions/30249069/listing-contents-of-a-bucket-with-boto3
# 

import boto3
import botocore

#BUCKET_NAME = 'chid-bucket' # replace with your bucket name
#FILE_NAME= 'file.txt' # replace with the your specific file that exists in your bucket
#InputDir = './TDCS_Download_jdwang/M06A/202212/'
#FILE_NAME = 'TDCS_M06A_20221201_030000.csv'
#InputFileLocation = InputDir+FILE_NAME;

BUCKET_NAME = 'tdcs-m06a-jdwang-2023'
#OBJECT_NAME = FILE_NAME

s3 = boto3.resource('s3')

my_bucket = s3.Bucket(BUCKET_NAME)

for file in my_bucket.objects.all():
    print(file.key)
