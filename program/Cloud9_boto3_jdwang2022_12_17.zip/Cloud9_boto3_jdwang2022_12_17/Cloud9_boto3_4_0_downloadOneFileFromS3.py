#
# From: https://github.com/rchidana/Python_Boto3/blob/master/S3download.py
# rchidana

import boto3
import botocore

#BUCKET_NAME = 'chid-bucket' # replace with your bucket name
#FILE_NAME= 'file.txt' # replace with the your specific file that exists in your bucket
InputDir = './TDCS_Download_jdwang/M06A/202212/'
FILE_NAME = 'TDCS_M06A_20221201_040000.csv'
InputFileLocation = InputDir+FILE_NAME;

BUCKET_NAME = 'tdcs-m06a-jdwang-2022-12-16'
OBJECT_NAME = FILE_NAME

s3 = boto3.resource('s3')

try:
    s3.Bucket(BUCKET_NAME).download_file(FILE_NAME,FILE_NAME)
    print("Downloaded File : ",FILE_NAME," successfully from Bucket : ",BUCKET_NAME)
except botocore.exceptions.ClientError as e:
    if e.response['Error']['Code'] == "404":
        print("The File ",FILE_NAME," does not exist in Bucket : ",BUCKET_NAME)
    else:
        raise